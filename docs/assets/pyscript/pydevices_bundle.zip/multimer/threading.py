# SPDX-FileCopyrightText: 2024 Brad Barnett
#
# SPDX-License-Identifier: MIT
"""Thread-based software Timer."""

import sys

from . import _provider_pump, _provider_sleep_ms
from ._core import _TimerCore
from ._schedule import schedule
from ._ticks import _raw_sleep_ms as _sleep_ms
from ._ticks import ticks_add, ticks_diff, ticks_ms

name = "threading"
uses_interrupts = False
is_async = False
_defer_sync_arm = False


def pump():
    _provider_pump()


def sleep_ms(ms):
    _provider_sleep_ms(ms)


__all__ = ["Timer", "is_async", "name", "pump", "sleep_ms", "uses_interrupts"]

if sys.implementation.name == "cpython":
    import threading

    def _spawn(fn):
        threading.Thread(target=fn, daemon=True).start()

else:
    try:
        import _thread

        def _spawn(fn):
            _thread.start_new_thread(fn, ())

    except ImportError:
        try:
            import threading

            def _spawn(fn):
                threading.Thread(target=fn, daemon=True).start()

        except ImportError:
            raise ImportError("no thread support") from None


class Timer(_TimerCore):
    def __init__(self, id=-1, **kwargs):
        self._running = False
        # Pre-bind so the worker can ``schedule`` onto the main thread without
        # allocating a bound method each tick (and so soft coalesce runs inside
        # ``_deliver`` rather than bypassing it via ``_invoke_callback``).
        self._scheduled_deliver = self._run_deliver
        super().__init__(id, **kwargs)

    def _wait_idle(self):
        while self._busy:
            _sleep_ms(1)

    def _arm(self):
        self._running = True
        _spawn(self._loop)

    def _disarm(self):
        self._running = False

    def _run_deliver(self, _arg):
        self._deliver()

    def _loop(self):
        next_t = ticks_add(ticks_ms(), self._period_ms)
        while self._running:
            delay = ticks_diff(next_t, ticks_ms())
            if delay > 0:
                _sleep_ms(delay)
            if not self._running:
                break
            schedule(self._scheduled_deliver, self)
            if self._mode == self.ONE_SHOT:
                self._running = False
                break
            next_t = ticks_add(next_t, self._period_ms)
